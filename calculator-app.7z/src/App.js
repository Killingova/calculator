import React, { useState } from "react";
import "./App.css";

function App() {
  const [display, setDisplay] = useState("0");
  const [firstOperand, setFirstOperand] = useState(null);
  const [operator, setOperator] = useState(null);

  const handleNumberClick = (digit) => {
    setDisplay(display === "0" ? String(digit) : display + digit);
  };

  const handleDecimal = () => {
    if (!display.includes(".")) setDisplay(display + ".");
  };

  const handleOperatorClick = (op) => {
    setFirstOperand(parseFloat(display));
    setOperator(op);
    setDisplay("0");
  };

  const handleEquals = () => {
    if (operator && firstOperand !== null) {
      const secondOperand = parseFloat(display);
      let result = firstOperand;

      switch (operator) {
        case "+": result = firstOperand + secondOperand; break;
        case "-": result = firstOperand - secondOperand; break;
        case "×": result = firstOperand * secondOperand; break;
        case "÷":
          if (secondOperand === 0) {
            alert("Division durch 0 ist nicht möglich!");
            return;
          }
          result = firstOperand / secondOperand;
          break;
        default: break;
      }

      setDisplay(String(result));
      setFirstOperand(result);
      setOperator(null);
    }
  };

  const handleBackspace = () => {
    setDisplay(display.length === 1 ? "0" : display.slice(0, -1));
  };

  const handleAllClear = () => {
    setDisplay("0");
    setFirstOperand(null);
    setOperator(null);
  };

  return (
    <div className="calculator">
      <h1>React Calculator</h1>
      <div className="display">{display}</div>
      <div className="buttons">
        <button onClick={handleAllClear} className="btn special">AC</button>
        <button onClick={handleBackspace} className="btn special">⌫</button>
        <button onClick={() => handleOperatorClick("÷")} className="btn operator">÷</button>
        <button onClick={() => handleOperatorClick("×")} className="btn operator">×</button>
        <button onClick={() => handleNumberClick("7")} className="btn">7</button>
        <button onClick={() => handleNumberClick("8")} className="btn">8</button>
        <button onClick={() => handleNumberClick("9")} className="btn">9</button>
        <button onClick={() => handleOperatorClick("-")} className="btn operator">−</button>
        <button onClick={() => handleNumberClick("4")} className="btn">4</button>
        <button onClick={() => handleNumberClick("5")} className="btn">5</button>
        <button onClick={() => handleNumberClick("6")} className="btn">6</button>
        <button onClick={() => handleOperatorClick("+")} className="btn operator">+</button>
        <button onClick={() => handleNumberClick("1")} className="btn">1</button>
        <button onClick={() => handleNumberClick("2")} className="btn">2</button>
        <button onClick={() => handleNumberClick("3")} className="btn">3</button>
        <button onClick={handleEquals} className="btn equals">=</button>
        <button onClick={() => handleNumberClick("0")} className="btn zero">0</button>
        <button onClick={handleDecimal} className="btn">.</button>
      </div>
    </div>
  );
}

export default App;
